module.exports = {
    content: ["./*.html"], // Include all your HTML files
    theme: {
      extend: {
        animation: {
          'spin-slow': 'spin 5s linear infinite',
        },
      },
    },
    plugins: [],
  };
  